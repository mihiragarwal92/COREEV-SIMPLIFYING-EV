function scrollDown() {
    document.getElementById("scroll").scrollIntoView({behavior: "smooth"});
}
